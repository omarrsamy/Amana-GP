import React from 'react'

let hostURL = 'http://192.168.1.9:3000/api/v1/'

export default hostURL;